
# StudyBuddy Database/API Patch

This patch adds a `studybuddy` Django app with models, admin, REST API (DRF), and signals.

## What's included
- `studybuddy/models.py`: StudyUser, Task, StudySession, HydrationLog, Reminder
- `studybuddy/serializers.py`, `studybuddy/views.py`, `studybuddy/urls.py`
- `studybuddy/admin.py` (Django admin registrations)
- `studybuddy/apps.py` + `studybuddy/signals.py` (keeps tasks_done_total in sync)
- `requirements.txt` updated with `djangorestframework`
- Project `settings.py` updated to include `'rest_framework'` and `'studybuddy'`
- Project `urls.py` includes `studybuddy.urls` at root, so API is under `/api/`

## How to run (locally)

```bash
# from this repo root
cd Studybuddy/study_buddy

# (optional) create venv
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

pip install -r ../../requirements.txt
pip install django djangorestframework

# apply migrations
python manage.py makemigrations studybuddy
python manage.py migrate

# create admin user (optional)
python manage.py createsuperuser

# run server
python manage.py runserver
```

## API endpoints (examples)
- `POST /api/users/` — create StudyUser
- `POST /api/tasks/` — create Task
- `PATCH /api/tasks/<id>/` — update status to `"done"` (auto-updates `tasks_done_total` via signals)
- `POST /api/sessions/` — start session
- `PATCH /api/sessions/<id>/` — end session or update counters
- `POST /api/hydration/` — log hydration
- `POST /api/reminders/` — create reminder

