default_app_config = 'studybuddy.apps.StudybuddyConfig'
